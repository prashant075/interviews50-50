package z_lld.bookmyshow.model;

public enum BookingStatus {
    Created,
    Confirmed,
    Expired
}
