package z_lld.concurrency.DPP;

//state of chopstick
public enum State {
    LEFT,
    RIGHT;
}
