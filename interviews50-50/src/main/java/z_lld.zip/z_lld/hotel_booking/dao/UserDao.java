package z_lld.hotel_booking.dao;

public class UserDao {

}
