package z_lld.logger;

public class Application {
    public static void main(String[] args) {
        Logger logger = Logger.getLogger();
        logger.info("this is Info");
        //logger.debug("this is Debug");
    }
}
