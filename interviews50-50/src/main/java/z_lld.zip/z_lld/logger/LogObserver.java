package z_lld.logger;

interface LogObserver {
    void log(String msg);
}
