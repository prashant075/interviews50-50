package z_lld.java;

public class JavaSwitch17 {
    /*
    * pattern matching-> you can match pattern in case label(you can pass object to case)
    * Guarded pattern -> you can pass conditional Statement Inside case Value
    * Null Case
    *(use --enable-preview to enable patterns in switch statements)
    *  */

    public static void main(String[] args) {
        patternMatching(1);
    }
    public static String patternMatching(Object obj){
//        return switch (obj){
//            case Integer ->"Int";
//            case String -> "String";
//            default -> "Unknown";
//        };
        return "";
    }
}
