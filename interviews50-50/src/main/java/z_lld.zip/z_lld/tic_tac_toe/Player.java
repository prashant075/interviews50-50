package z_lld.tic_tac_toe;

public class Player {
    int id;
    int symbol;

    public Player(int id, int symbol) {
        this.id = id;
        this.symbol = symbol;
    }
}
