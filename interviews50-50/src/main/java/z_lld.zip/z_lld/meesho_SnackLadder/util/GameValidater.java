package z_lld.meesho_SnackLadder.util;

import z_lld.meesho_SnackLadder.entity.Game;

public class GameValidater {
    private void validateGame(Game game) {
        validateLadder(game);
        validatesnanks(game);
    }

    private void validatesnanks(Game game) {
        //for
    }

    private void validateLadder(Game game) {
    }
}

