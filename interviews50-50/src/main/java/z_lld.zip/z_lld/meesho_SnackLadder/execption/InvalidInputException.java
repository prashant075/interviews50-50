package z_lld.meesho_SnackLadder.execption;

public class InvalidInputException extends Exception {
    public InvalidInputException(String message) {
        super(message);
    }
}
