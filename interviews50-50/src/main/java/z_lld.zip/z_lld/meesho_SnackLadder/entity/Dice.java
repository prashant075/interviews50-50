package z_lld.meesho_SnackLadder.entity;

public class Dice  {
    private Object lock;

    public void lockDice(){

    }
}
