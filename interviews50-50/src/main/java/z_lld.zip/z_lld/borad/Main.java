package z_lld.borad;

public class Main {
    public static void main(String[] args) {
        MainInput mainInput = new MainInput();
        mainInput.mainIn();
    }
}
